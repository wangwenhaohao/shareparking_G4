import unittest

from sharedcarspacing.tools.uitil import APIUtil
from sharedcarspacing.tools.uitil import FileUtil

class PersonalInfo(unittest.TestCase):

    def test_modify_info(self):
        test_info = FileUtil.get_test_info('..\\conf\\test_info.ini', 'order', 'personal_info_api')
        APIUtil.assert_api(test_info)

    def test_bind_account(self):
        test_info = FileUtil.get_test_info('..\\conf\\test_info.ini', 'order', 'bind_account_api')
        APIUtil.assert_api(test_info)


if __name__ == '__main__':
    PersonalInfo().test_modify_info()
    # PersonalInfo().test_bind_account()