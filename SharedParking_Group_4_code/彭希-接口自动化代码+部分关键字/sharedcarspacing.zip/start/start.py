import unittest

from HTMLTestRunner import HTMLTestRunner

from woniusalesV1.tools.ui_util import FileUtil


class Start:
    def start(self, path):
        suite = unittest.TestSuite()
        loader = unittest.TestLoader()
        test_class_info = FileUtil.get_txt_line(path)
        tests = loader.loadTestsFromNames(test_class_info)
        suite.addTests(tests)

        with open('report.html', 'w') as file:
            runner = HTMLTestRunner(stream=file, verbosity=2)
            runner.run(suite)

if __name__ == '__main__':
    Start().start("..\\conf\\case_class_path.conf")
