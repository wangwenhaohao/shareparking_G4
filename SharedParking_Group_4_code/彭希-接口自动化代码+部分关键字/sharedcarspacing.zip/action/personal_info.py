from sharedcarspacing.tools.uitil import APIUtil
from  sharedcarspacing.tools.uitil import FileUtil

class PersonalAPI:
    def modify_personal(self):
        personal_test_info = FileUtil.get_test_info('..\\conf\\test_info.ini','history','history_order_api')
        for test_info in personal_test_info:
            personal_resp = APIUtil.request(test_info['request_method'], test_info['uri'], test_info['params'])
            print(personal_resp.text)
        return personal_resp.text

if __name__ == '__main__':
    PersonalAPI().modify_personal()